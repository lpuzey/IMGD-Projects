Linda Puzey 
Extensions

GML Tutorial:

1. I made it so that you can use the keys W,A,S,D as well as the arrow keys
2. I changed the player sprite to Harry Potter
3. I changed the enemy sprite to a Dementor
4. I changed the bullet sprite to a Stag Patronus
5. I added a theme song for the game
6. I added new background tiles
7. I moved the score to the middle
8. I added a game over screen
9. I made it so you can press space to play the game again from the game over screen
10. I changed the cooldown so the bullets shoot slower

