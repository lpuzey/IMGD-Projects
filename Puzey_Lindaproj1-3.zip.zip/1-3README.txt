Linda Puzey 
Extensions

Pong:

1. I added a score for each player
2. I made it so the ball gets faster with each hit

