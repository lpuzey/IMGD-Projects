Linda Puzey
Extensions

DnD Tutorial:

1. I made it so that you can use the keys W,A,S,D, as well as the arrow keys
2. I added a theme song for the game
3. I added the Power Rangers logo to the title screen
4. I changed the player sprite to the red ranger head
5. I changed the enemy sprite to a putty patrol head
6. I added a game over screen
7. I made it so you can press space to play the game again from the game over screen
8. I made it so the score will display on the game over screen


